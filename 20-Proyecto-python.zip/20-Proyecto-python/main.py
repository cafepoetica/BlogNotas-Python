"""
Proyecto Python Mysql
-Abrir asistente
-Login o registro
-Crear usuario en bbdd
-identificacion usuario
-Crear nota
-Mostrar nota
-Borrar nota
"""

print("""

Acciones disponibles:
    - Registro
    - Login

""")
from usuarios import acciones

hazEl= acciones.Acciones()
accion=input("¿ Que desea hacer ?")


if accion=="Registro":
   hazEl.registro()

elif accion=="Login":
    hazEl.login()


